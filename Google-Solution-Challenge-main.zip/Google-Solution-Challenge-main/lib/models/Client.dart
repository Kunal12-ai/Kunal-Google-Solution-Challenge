class Client {
  final String name;
  final String company;
  final String profileUrl;

  Client({
    this.name,
    this.company,
    this.profileUrl,
  });
}
